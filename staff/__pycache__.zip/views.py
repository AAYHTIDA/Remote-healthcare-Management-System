
from django.shortcuts import render, get_object_or_404
from .models import Staff
from django.shortcuts import render, redirect
from .forms import StaffForm 

def staff_list(request):
    staff_members = Staff.objects.all()
    return render(request, 'staff/staff_list.html', {'staff_members': staff_members})


def staff_list(request):
    staff_list = Staff.objects.all()
    return render(request, 'staff/staff_list.html', {'staff_list': staff_list})

def staff_detail(request, id):
    staff = Staff.objects.get(id=id)
    return render(request, 'staff/staff_detail.html', {'staff': staff})

def staff_create(request):
    if request.method == 'POST':
        form = StaffForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('staff_list')
    else:
        form = StaffForm()
    return render(request, 'staff/staff_form.html', {'form': form, 'form_title': 'Add New Staff'})

def staff_edit(request, id):
    staff = Staff.objects.get(id=id)
    if request.method == 'POST':
        form = StaffForm(request.POST, instance=staff)
        if form.is_valid():
            form.save()
            return redirect('staff_list')
    else:
        form = StaffForm(instance=staff)
    return render(request, 'staff/staff_form.html', {'form': form, 'form_title': 'Edit Staff'})


def staff_list(request):
    staff_list = Staff.objects.all()
    return render(request, 'staff/staff_list.html', {'staff_list': staff_list})

def staff_detail(request, id):
    staff = Staff.objects.get(id=id)
    return render(request, 'staff/staff_detail.html', {'staff': staff})

def staff_create(request):
    if request.method == 'POST':
        form = StaffForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('staff_list')
    else:
        form = StaffForm()
    return render(request, 'staff/staff_form.html', {'form': form, 'form_title': 'Add New Staff'})

def staff_edit(request, id):
    staff = Staff.objects.get(id=id)
    if request.method == 'POST':
        form = StaffForm(request.POST, instance=staff)
        if form.is_valid():
            form.save()
            return redirect('staff_list')
    else:
        form = StaffForm(instance=staff)
    return render(request, 'staff/staff_form.html', {'form': form, 'form_title': 'Edit Staff'})

# Add this view for the 'base_staff' URL pattern
def base_staff(request):
    return render(request, 'staff/base_staff.html')
